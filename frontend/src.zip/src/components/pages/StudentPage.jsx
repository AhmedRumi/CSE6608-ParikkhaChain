import { useEffect, useState } from 'react'
import { jsPDF } from 'jspdf'
import autoTable from 'jspdf-autotable'
import { sendTx } from '../ui'
import { getContract, GRADE_STATUS, EXAM_STATES, RESCRUTINY_STATUS } from '../../chain/contracts'
import { formatError, shortAddress } from '../../chain/provider'
import { ArrowLeft, Check, Download, LockKeyhole, Search, X } from 'lucide-react'

/**
 * Grading scale (percentage out of 100 per exam) — adjustable.
 * Marks = Section A + Section B, each with customizable totals
 * (default 50/50; per-exam totals come from ExamLifecycle).
 */
const GRADE_TABLE = [
  { min: 80, grade: 'A+', point: 4.0 },
  { min: 75, grade: 'A',  point: 3.8 },
  { min: 70, grade: 'A-', point: 3.5 },
  { min: 65, grade: 'B+', point: 3.2 },
  { min: 60, grade: 'B',  point: 3.0 },
  { min: 55, grade: 'B-', point: 2.7 },
  { min: 50, grade: 'C+', point: 2.3 },
  { min: 45, grade: 'C',  point: 2.0 },
  { min: 40, grade: 'D',  point: 1.0 },
  { min: 0,  grade: 'F',  point: 0.0 },
]

export function gradeOf(marks) {
  for (const g of GRADE_TABLE) if (marks >= g.min) return g
  return GRADE_TABLE[GRADE_TABLE.length - 1]
}

/** Grade from raw marks against a custom exam total (percentage-based). */
export function gradeFor(marks, totalMax) {
  if (!totalMax) return gradeOf(marks)
  return gradeOf(Math.round((marks * 100) / totalMax))
}
const GRADED = ['APPROVED', 'FINALIZED']
const GRADED_IDX = [4, 5]

/**
 * Student view — only the caller's OWN results (contract-enforced via
 * onlyAdminOrSelf in getFullTranscript / getStudentExamResult).
 * - Students register for offered courses themselves (registerForCourse,
 *   auto-enrollment; admin can still override).
 * - Results are LOCKED until the admin marks the exam COMPLETED AND every
 *   registered course's marks are APPROVED (contract-enforced:
 *   getFullTranscript reverts while any course is pending). The UI mirrors
 *   the same rule via public getters.
 * - NOT_SUBMITTED rows are never shown.
 * Per-section marks are derived from PUBLIC on-chain events
 * (SectionMarksSubmitted / ScrutinyResponse), so no admin getters are used.
 */
export default function StudentPage({ account, signer }) {
  const [offered, setOffered] = useState(null)
  const [terms, setTerms] = useState(null)
  const [selectedTerm, setSelectedTerm] = useState(null)
  const [enrolled, setEnrolled] = useState([])
  const [rows, setRows] = useState(null)
  const [locked, setLocked] = useState(false)
  const [lockPending, setLockPending] = useState([])
  const [hasScripts, setHasScripts] = useState(false)
  const [rescrutiny, setRescrutiny] = useState({})
  const [applyForm, setApplyForm] = useState(null)
  const [reasonDraft, setReasonDraft] = useState('')
  const [error, setError] = useState(null)
  const [reload, setReload] = useState(0)

  useEffect(() => {
    let cancelled = false
    ;(async () => {
      try {
        const exam = getContract('ExamLifecycle')
        const hash = getContract('HashRegistry')
        const result = getContract('ResultAudit')

        // 1. My enrolled (registered) exams
        const myExamIds = (await exam.getStudentExams(account)).map(Number)

        // 2. My scripts → per-exam pair { A: sid, B: sid }
        //    (Sec A and Sec B are SEPARATE scripts, each with its own examiner)
        let myScripts = []
        try { myScripts = await hash.getStudentScripts(account) } catch { /* no scripts yet */ }
        const scriptsByExam = new Map()
        if (myScripts.length) {
          const examsOf = await Promise.all(myScripts.map((s) => hash.getExamId(s)))
          const sections = await Promise.all(myScripts.map((s) => hash.getScriptSection(s)))
          myScripts.forEach((s, i) => {
            const eid = Number(examsOf[i])
            if (!scriptsByExam.has(eid)) scriptsByExam.set(eid, {})
            scriptsByExam.get(eid)[Number(sections[i]) === 1 ? 'A' : 'B'] = s
          })
        }

        // 3. Enrolled courses + per-section approval status
        const enrolledList = []
        let anyPending = false

        // 3a. My rescrutiny applications (keyed "examId:section")
        const rescrutinyMap = {}
        try {
          const rescr = getContract('Rescrutiny')
          const appCount = Number(await rescr.getStudentApplicationCount(account))
          if (appCount > 0) {
            const [sids, examIds, sections, statuses, marksUpdated, reasons] =
              await rescr.getStudentApplications(account)
            for (let i = 0; i < sids.length; i++) {
              rescrutinyMap[`${Number(examIds[i])}:${Number(sections[i])}`] = {
                sid: sids[i],
                status: Number(statuses[i]),
                marksUpdated: marksUpdated[i],
                reason: reasons[i],
              }
            }
          }
        } catch { /* Rescrutiny not deployed yet */ }

        for (const eid of myExamIds) {
          const d = await exam.getExamDetails(eid)
          const pair = scriptsByExam.get(eid) || {}
          const marksOf = async (sid) => {
            if (!sid) return null
            try {
              const m = await result.getMarks(sid)
              return { marks: Number(m[0]), total: Number(m[1]), status: Number(m[2]) }
            } catch { return { marks: 0, total: 50, status: 0 } }
          }
          const a = await marksOf(pair.A)
          const b = await marksOf(pair.B)
          const stA = a ? a.status : 0
          const stB = b ? b.status : 0
          const examState = Number(d[3])
          const pending =
            (examState !== 4 && examState !== 5) ||
            (stA > 0 && !GRADED_IDX.includes(stA)) ||
            (stB > 0 && !GRADED_IDX.includes(stB))
          enrolledList.push({
            examId: eid,
            title: d[0],
            course: d[1],
            term: Number(d[5]) ? await exam.getTermName(Number(d[5])) : 'General',
            secA: Number(d[6]),
            secB: Number(d[7]),
            examState,
            scriptA: pair.A,
            scriptB: pair.B,
            statusA: stA,
            statusB: stB,
            pending,
          })
          if (pending) anyPending = true
        }

        // 4. Offered courses (CREATED or ACTIVE) I haven't registered yet
        const total = Number(await exam.getTotalExams())
        const offeredList = []
        for (let id = 1; id <= total; id++) {
          if (myExamIds.includes(id)) continue
          const d = await exam.getExamDetails(id)
          const st = Number(d[3])
          if (st !== 0 && st !== 1) continue
          const termId = Number(d[5])
          offeredList.push({
            examId: id,
            title: d[0],
            course: d[1],
            termId,
            term: termId ? await exam.getTermName(termId) : 'General',
            secA: Number(d[6]),
            secB: Number(d[7]),
            date: Number(d[2]),
          })
        }

        // 5. Terms (Examination Types) — grouped listing for registration
        const termCount = Number(await exam.getTermCount())
        const termsList = []
        for (let id = 1; id <= termCount; id++) {
          termsList.push({ termId: id, name: await exam.getTermName(id) })
        }
        if (offeredList.some((c) => c.termId === 0)) {
          termsList.push({ termId: 0, name: 'General' })
        }

        // 6. Transcript — only when unlocked AND the student has scripts
        //    (getFullTranscript -> getStudentScripts reverts with
        //    "No scripts found for this student" when no script exists yet)
        let rowsOut = null
        let hasScripts = myScripts.length > 0
        if (!anyPending && hasScripts) {
          const t = await result.getFullTranscript(account, { from: account })
          const details = new Map()
          for (const eid of t.examIds) {
            if (!details.has(Number(eid))) {
              try {
                const d = await exam.getExamDetails(Number(eid))
                details.set(Number(eid), { title: d[0], course: d[1], secA: Number(d[6]), secB: Number(d[7]) })
              } catch {
                details.set(Number(eid), { title: '', course: '', secA: 50, secB: 50 })
              }
            }
          }
          const out = []
          for (let i = 0; i < t.examIds.length; i++) {
            const eid = Number(t.examIds[i])
            const meta = details.get(eid) || { title: '', course: '', secA: 50, secB: 50 }
            const [a, b] = await Promise.all([
              t.scriptIdsA[i] ? sectionMarksFromEvents(t.scriptIdsA[i]) : { a: 0, b: 0 },
              t.scriptIdsB[i] ? sectionMarksFromEvents(t.scriptIdsB[i]) : { a: 0, b: 0 },
            ])
            out.push({
              examId: eid,
              title: meta.title,
              course: meta.course,
              scriptA: t.scriptIdsA[i],
              scriptB: t.scriptIdsB[i],
              marksA: t.scriptIdsA[i] ? a.a : 0,
              marksB: t.scriptIdsB[i] ? b.b : 0,
              secA: meta.secA,
              secB: meta.secB,
              total: Number(t.marksObtained[i]),
              totalMax: Number(t.totalMarks[i]),
              status: GRADE_STATUS[Number(t.statuses[i])] || String(t.statuses[i]),
              hasScrutiny: t.hasScrutiny[i],
            })
          }
          rowsOut = out
        }

        if (!cancelled) {
          setOffered(offeredList)
          setTerms(termsList)
          setEnrolled(enrolledList)
          setLocked(anyPending)
          setLockPending(enrolledList.filter((x) => x.pending))
          setRows(rowsOut)
          setHasScripts(hasScripts)
          setRescrutiny(rescrutinyMap)
          setApplyForm(null)
          setReasonDraft('')
        }
      } catch (e) {
        if (!cancelled) setError(formatError(e))
      }
    })()
    return () => { cancelled = true }
  }, [account, reload])

  if (error) return <div className="error-box"><span className="status-icon"><X size={15} strokeWidth={2.5} aria-hidden="true" /></span>{error}</div>
  if (offered === null) return <div className="loading">Loading your courses…</div>

  const visible = (rows || []).filter((r) => r.status !== 'NOT_SUBMITTED')
  const graded = visible.filter((r) => GRADED.includes(r.status))
  const gpa = graded.length
    ? graded.reduce((s, r) => s + gradeFor(r.total, r.totalMax).point, 0) / graded.length
    : null

  return (
    <div className="page">
      <h2>Student View</h2>

      <h3>Register for Offered Courses</h3>
      {offered.length === 0 ? (
        <div className="info-box">
          No open courses to register right now — check back once the admin
          creates a term and opens courses.
        </div>
      ) : selectedTerm === null ? (
        <>
          <p className="hint">
            Pick an Examination Type (Term) to see its open courses. Registering
            auto-enrolls you on-chain (admin can still customize).
          </p>
          <div className="term-grid">
            {(terms || []).map((t) => {
              const open = offered.filter((c) => c.termId === t.termId)
              if (open.length === 0) return null
              return (
                <button
                  key={t.termId}
                  type="button"
                  className="term-card"
                  onClick={() => setSelectedTerm(t.termId)}
                >
                  <strong>{t.name}</strong>
                  <span>{open.length} open {open.length === 1 ? 'course' : 'courses'}</span>
                </button>
              )
            })}
          </div>
        </>
      ) : (
        <>
          <button type="button" className="btn-sm" onClick={() => setSelectedTerm(null)}>
            <ArrowLeft size={14} aria-hidden="true" /> All Examination Types
          </button>
          <h4 className="term-title">
            {(terms || []).find((t) => t.termId === selectedTerm)?.name || 'General'}
          </h4>
          <div className="table-scroll">
          <table className="data-table">
            <thead>
              <tr>
                <th>Course</th>
                <th>Exam</th>
                <th>Sec A / Sec B</th>
                <th>Date</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {offered
                .filter((c) => c.termId === selectedTerm)
                .map((c) => (
                  <tr key={c.examId}>
                    <td>{c.course}</td>
                    <td>{c.title || `Exam ${c.examId}`}</td>
                    <td>{c.secA} / {c.secB}</td>
                    <td>{new Date(c.date * 1000).toLocaleDateString()}</td>
                    <td>
                      <button
                        className="btn-sm"
                        onClick={async () => {
                          try {
                            await sendTx(signer, 'ExamLifecycle', 'registerForCourse', c.examId)
                            setReload((r) => r + 1)
                          } catch (e) {
                            setError(formatError(e))
                          }
                        }}
                      >
                        Register (tx)
                      </button>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
          </div>
        </>
      )}

      <h3>My Registered Courses</h3>
      {enrolled.length === 0 ? (
        <div className="info-box">You haven't registered for any course yet.</div>
      ) : (
        <div className="table-scroll">
        <table className="data-table">
          <thead>
            <tr>
              <th>Course</th>
              <th>Exam</th>
              <th>Term</th>
              <th>Script A</th>
              <th>Script B</th>
            </tr>
          </thead>
          <tbody>
            {enrolled.map((c) => (
              <tr key={c.examId}>
                <td>{c.course}</td>
                <td>{c.title || `Exam ${c.examId}`}</td>
                <td>{c.term}</td>
                <td>
                  {c.scriptA ? (
                    <>
                      <span className={`state state-${(GRADE_STATUS[c.statusA] || '').toLowerCase()}`}>
                        {GRADE_STATUS[c.statusA]}
                      </span>
                      <RescrutinySection
                        examId={c.examId}
                        section={1}
                        examState={c.examState}
                        sectionStatus={c.statusA}
                        app={rescrutiny[`${c.examId}:1`]}
                        signer={signer}
                        applyForm={applyForm}
                        reasonDraft={reasonDraft}
                        setApplyForm={setApplyForm}
                        setReasonDraft={setReasonDraft}
                        setError={setError}
                        onReload={() => setReload((r) => r + 1)}
                      />
                    </>
                  ) : (
                    <span className="section-chip">script pending</span>
                  )}
                </td>
                <td>
                  {c.scriptB ? (
                    <>
                      <span className={`state state-${(GRADE_STATUS[c.statusB] || '').toLowerCase()}`}>
                        {GRADE_STATUS[c.statusB]}
                      </span>
                      <RescrutinySection
                        examId={c.examId}
                        section={2}
                        examState={c.examState}
                        sectionStatus={c.statusB}
                        app={rescrutiny[`${c.examId}:2`]}
                        signer={signer}
                        applyForm={applyForm}
                        reasonDraft={reasonDraft}
                        setApplyForm={setApplyForm}
                        setReasonDraft={setReasonDraft}
                        setError={setError}
                        onReload={() => setReload((r) => r + 1)}
                      />
                    </>
                  ) : (
                    <span className="section-chip">script pending</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        </div>
      )}

      {locked ? (
        <div className="info-box warning">
          <LockKeyhole size={15} className="inline-icon" aria-hidden="true" />{' '}
          <strong>Results are locked.</strong> Your gradesheet is released
          only after the admin marks each exam{' '}
          <strong>COMPLETED or FINALIZED</strong> and all sections are approved. Pending:{' '}
          {lockPending
            .map((c) =>
              c.examState !== 4 && c.examState !== 5
                ? `${c.course} (exam: ${EXAM_STATES[c.examState]})`
                : `${c.course} (A: ${GRADE_STATUS[c.statusA]}, B: ${GRADE_STATUS[c.statusB]})`
            )
            .join(', ')}
          .
        </div>
      ) : rows === null ? (
        <div className="info-box">
          {hasScripts
            ? 'Your gradesheet is ready to generate once marks are recorded. Nothing to show yet.'
            : 'Your registration is saved, but no script has been assigned to you yet. ' +
              'Once the admin assigns your script (after examiners are set), results will appear here.'}
        </div>
      ) : visible.length === 0 ? (
        <div className="info-box">
          No graded results to display yet (marks are recorded for your
          registered courses but nothing is approved).
        </div>
      ) : (
        <>
          <div className="gpa-box">
            <div>
              <strong>CGPA: {gpa !== null ? gpa.toFixed(2) : '—'}</strong>
              <br />
              <span>
                {graded.length} graded {graded.length === 1 ? 'course' : 'courses'}
              </span>
            </div>
            <button className="btn-sm" onClick={() => downloadGradesheet(visible, account, gpa)}>
              <Download size={14} aria-hidden="true" /> Download Gradesheet (PDF)
            </button>
            <div className="seal" title="Results verified on-chain">
              VERIFIED
              <small>on-chain</small>
            </div>
          </div>
          <div className="table-scroll">
          <table className="data-table">
            <thead>
              <tr>
                <th>Course</th>
                <th>Exam</th>
                <th>Sec A</th>
                <th>Sec B</th>
                <th>Total</th>
                <th>Grade</th>
                <th>Point</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {visible.map((r, i) => {
                const g = gradeFor(r.total, r.totalMax)
                const eligible = GRADED.includes(r.status)
                return (
                  <tr key={i}>
                    <td>
                      {r.course}
                      {r.title && <div className="feed-block">{r.title}</div>}
                    </td>
                    <td>
                      Exam {r.examId}
                      {r.scriptA && <div className="feed-block mono">A: {shortAddress(r.scriptA)}</div>}
                      {r.scriptB && <div className="feed-block mono">B: {shortAddress(r.scriptB)}</div>}
                    </td>
                    <td>{r.marksA}/{r.secA}</td>
                    <td>{r.marksB}/{r.secB}</td>
                    <td>
                      <strong>{r.marksA + r.marksB}/{r.totalMax}</strong>
                    </td>
                    <td>{eligible ? <strong>{g.grade}</strong> : '—'}</td>
                    <td>{eligible ? g.point.toFixed(2) : '—'}</td>
                    <td>
                      <span className={`state state-${r.status.toLowerCase()}`}>{r.status}</span>
                      {r.hasScrutiny && <span className="section-chip">reviewed</span>}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
          </div>
        </>
      )}
    </div>
  )
}

/**
 * Per-section rescrutiny controls (student side).
 * Visible only while the exam is COMPLETED and the section's marks are
 * APPROVED. Shows the application status; on APPROVED tells the student
 * the re-evaluation is done and the revised score is shown in the
 * gradesheet below. Non-applicants see nothing.
 */
function RescrutinySection({
  examId,
  section,
  examState,
  sectionStatus,
  app,
  signer,
  applyForm,
  reasonDraft,
  setApplyForm,
  setReasonDraft,
  setError,
  onReload,
}) {
  if (examState !== 4 || sectionStatus !== 4) return null
  const isForm = applyForm && applyForm.examId === examId && applyForm.section === section
  if (app) {
    const label = RESCRUTINY_STATUS[app.status] || String(app.status)
    return (
      <span>
        {app.status === 3 ? (
          <span className="rescrutiny-done">
            <Check size={14} className="inline-icon" aria-hidden="true" /> Re-evaluation done — revised score shown
          </span>
        ) : (
          <>
            <span className={`state state-${label.toLowerCase()}`}>Rescrutiny: {label}</span>
            {app.status === 0 && <div className="scrutiny-note">under scrutiny — awaiting scrutinizer review</div>}
            {app.status === 1 && <div className="scrutiny-note">sent back to examiner</div>}
            {app.status === 2 && <div className="scrutiny-note">awaiting scrutinizer approval</div>}
          </>
        )}
      </span>
    )
  }
  return (
    <span>
      {isForm ? (
        <div className="rescrutiny-form">
          <textarea
            rows="2"
            placeholder="Reason for re-evaluation…"
            value={reasonDraft}
            onChange={(e) => setReasonDraft(e.target.value)}
          />
          <div className="inline-actions">
            <button
              type="button"
              className="btn-sm"
              disabled={!reasonDraft.trim()}
              onClick={async () => {
                try {
                  await sendTx(signer, 'Rescrutiny', 'applyForRescrutiny', examId, section, reasonDraft.trim())
                  onReload()
                } catch (e) {
                  setError(formatError(e))
                }
              }}
            >
              Submit (tx)
            </button>
            <button type="button" className="btn-sm" onClick={() => setApplyForm(null)}>
              Cancel
            </button>
          </div>
        </div>
      ) : (
        <button
          type="button"
          className="btn-sm"
          onClick={() => {
            setReasonDraft('')
            setApplyForm({ examId, section })
          }}
        >
          <Search size={14} aria-hidden="true" /> Request Rescrutiny
        </button>
      )}
    </span>
  )
}

/** Per-section marks from public events (latest submission/response wins). */
async function sectionMarksFromEvents(sid) {
  const result = getContract('ResultAudit')
  const [subs, resps, rescrUpdates] = await Promise.all([
    result.queryFilter(result.filters.SectionMarksSubmitted(sid), 0, 'latest'),
    result.queryFilter(result.filters.ScrutinyResponse(sid), 0, 'latest'),
    result.queryFilter(result.filters.MarksUpdatedAfterRescrutiny(sid), 0, 'latest'),
  ])
  const A = { block: 0, marks: 0 }
  const B = { block: 0, marks: 0 }
  for (const e of subs) {
    const sec = Number(e.args[2])
    const d = sec === 1 ? A : B
    if (Number(e.blockNumber) >= d.block) d.marks = Number(e.args[3])
  }
  for (const e of resps) {
    const sec = Number(e.args[1])
    const d = sec === 1 ? A : B
    if (Number(e.blockNumber) >= d.block) d.marks = Number(e.args[3])
  }
  for (const e of rescrUpdates) {
    const sec = Number(e.args[2])
    const d = sec === 1 ? A : B
    if (Number(e.blockNumber) >= d.block) d.marks = Number(e.args[4])
  }
  return { a: A.marks, b: B.marks }
}

function downloadGradesheet(rows, account, gpa) {
  const doc = new jsPDF()
  doc.setFontSize(16)
  doc.text('ParikkhaChain — Official Gradesheet', 14, 16)
  doc.setFontSize(10)
  doc.text(
    `Student: ${account}`,
    14,
    23
  )
  doc.text(`Generated: ${new Date().toLocaleString()} · Ganache (chain 1337)`, 14, 28)
  autoTable(doc, {
    startY: 33,
    head: [['#', 'Course', 'Exam', 'Sec A', 'Sec B', 'Total', 'Grade', 'Point', 'Status']],
    body: rows.map((r, i) => {
      const g = gradeFor(r.total, r.totalMax)
      const eligible = GRADED.includes(r.status)
      return [
        i + 1,
        r.course,
        `Exam ${r.examId}${r.title ? ` (${r.title})` : ''}`,
        `${r.marksA}/${r.secA}`,
        `${r.marksB}/${r.secB}`,
        `${r.marksA + r.marksB}/${r.totalMax}`,
        eligible ? g.grade : '—',
        eligible ? g.point.toFixed(2) : '—',
        r.status,
      ]
    }),
    foot: gpa !== null
      ? [[{}, '', '', '', 'CGPA', gpa.toFixed(2), '', '', `${rows.filter((r) => GRADED.includes(r.status)).length} grade(s)`]]
      : undefined,
    styles: { fontSize: 9 },
    headStyles: { fillColor: [31, 41, 55] },
    footStyles: { fillColor: [220, 220, 220], textColor: 20 },
  })
  const endY = doc.lastAutoTable.finalY + 5
  doc.setFontSize(8)
  doc.setTextColor(120)
  doc.text(
    'Blockchain-verified: grades, marks and scrutiny events are stored on-chain; only the student (or admin) may view them.',
    14,
    endY
  )
  doc.save(`ParikkhaChain_Gradesheet_${account.slice(0, 8)}.pdf`)
}
