import { useEffect, useState } from 'react'
import { TxForm, sendTx, StatusLine } from '../../ui'
import { getContract } from '../../../chain/contracts'
import { shortAddress, formatError } from '../../../chain/provider'
import { Check, X } from 'lucide-react'

export default function ScriptsTab({ signer, account }) {
  const [scripts, setScripts] = useState(null)
  const [scriptsError, setScriptsError] = useState(null)
  const [listExamId, setListExamId] = useState('')
  const [revealed, setRevealed] = useState(null)
  const [revealError, setRevealError] = useState(null)
  const [revealScriptId, setRevealScriptId] = useState('')
  const [verified, setVerified] = useState(null)
  const [exams, setExams] = useState(null)

  useEffect(() => {
    let cancelled = false
    ;(async () => {
      try {
        const exam = getContract('ExamLifecycle')
        const total = Number(await exam.getTotalExams())
        const list = []
        for (let id = 1; id <= total; id++) {
          const d = await exam.getExamDetails(id)
          list.push({ examId: id, course: d[1], name: d[0] })
        }
        if (!cancelled) setExams(list)
      } catch {
        if (!cancelled) setExams([])
      }
    })()
    return () => { cancelled = true }
  }, [])

  const examOptions = (exams || []).map((e) => ({
    value: String(e.examId),
    label: `Exam ${e.examId} · ${e.course}${e.name ? ` · ${e.name}` : ''}`,
  }))
  const courseOptions = [...new Map((exams || []).map((e) => [e.course, e])).values()].map((e) => ({
    value: e.course,
    label: `${e.course} · Exam ${e.examId}${e.name ? ` · ${e.name}` : ''}`,
  }))

  const loadScripts = async (e) => {
    e.preventDefault()
    setScriptsError(null)
    setScripts(null)
    try {
      const hash = getContract('HashRegistry')
      const list = await hash.getExamScripts(Number(listExamId))
      const withSections = await Promise.all(
        list.map(async (s) => ({
          sid: s,
          section: Number(await hash.getScriptSection(s)),
        }))
      )
      setScripts(withSections)
    } catch (err) {
      setScriptsError(formatError(err))
    }
  }

  const doReveal = async (e) => {
    e.preventDefault()
    setRevealError(null)
    setRevealed(null)
    try {
      const hash = getContract('HashRegistry')
      const r = await hash.revealStudent(revealScriptId, { from: account })
      setRevealed({ address: r[0], name: r[1], id: r[2], course: r[3] })
    } catch (err) {
      setRevealError(formatError(err))
    }
  }

  const doVerify = async (e) => {
    e.preventDefault()
    const v = new FormData(e.target)
    const hash = getContract('HashRegistry')
    const ok = await hash.verifyTopsheet(
      v.get('scriptId'),
      v.get('studentName'),
      v.get('studentId'),
      v.get('courseCode')
    )
    setVerified(ok)
  }

  return (
    <div>
      <div className="grid-2">
        <div>
          <h3>Register Script (Anonymization)</h3>
          <TxForm
            title="Sec A and Sec B are SEPARATE scripts — register each section once"
            fields={[
              { name: 'examId', label: 'Exam', type: 'select', options: examOptions },
              { name: 'section', label: 'Section', type: 'select', options: [{ value: '1', label: 'A' }, { value: '2', label: 'B' }], initial: '1' },
              { name: 'studentAddress', label: 'Student address' },
              { name: 'studentName', label: 'Student name' },
              { name: 'studentId', label: 'Student ID' },
              { name: 'courseCode', label: 'Course code', type: 'select', options: courseOptions },
            ]}
            onSubmit={async (v) => {
              const hash = getContract('HashRegistry').connect(signer)
              const tx = await hash.registerScriptFromTopsheet(
                Number(v.examId),
                Number(v.section),
                v.studentAddress,
                v.studentName,
                v.studentId,
                v.courseCode
              )
              const rec = await tx.wait()
              const logs = await hash.queryFilter(hash.filters.ScriptRegistered(), rec.blockNumber, rec.blockNumber)
              const e = logs[0]
              const hashShort = String(e.args[0]).slice(0, 26)
              return `tx ${tx.hash.slice(0, 12)}… · block ${rec.blockNumber} · scriptId ${hashShort}… (Section ${v.section === '1' ? 'A' : 'B'})`
            }}
            submitLabel="Register script (tx)"
          />
          <h3>Verify Topsheet</h3>
          <form className="tx-form" onSubmit={doVerify}>
            <label className="field">
              <span>Script ID</span>
              <input name="scriptId" required placeholder="SCRIPT_…" />
            </label>
            <label className="field">
              <span>Student name</span>
              <input name="studentName" required />
            </label>
            <label className="field">
              <span>Student ID</span>
              <input name="studentId" required />
            </label>
            <label className="field">
              <span>Course code</span>
              <select name="courseCode" required>
                {courseOptions.length === 0 && <option value="">No courses yet</option>}
                {courseOptions.map((o) => (
                  <option key={o.value} value={o.value}>{o.label}</option>
                ))}
              </select>
            </label>
            <button type="submit">Verify (view)</button>
            {verified !== null && (
              <div className={`status ${verified ? 'status-ok' : 'status-err'}`}>
                <span className="status-icon">
                  {verified ? (
                    <Check size={14} strokeWidth={2.5} aria-hidden="true" />
                  ) : (
                    <X size={14} strokeWidth={2.5} aria-hidden="true" />
                  )}
                </span>
                {verified ? 'Topsheet matches — hash verified' : 'Topsheet does NOT match'}
              </div>
            )}
          </form>
        </div>

        <div>
          <h3>Reveal & Inspect</h3>
          <form className="tx-form" onSubmit={doReveal}>
            <h4>Reveal student identity (admin view)</h4>
            <label className="field">
              <span>Script ID</span>
              <input value={revealScriptId} onChange={(e) => setRevealScriptId(e.target.value)} placeholder="SCRIPT_…" />
            </label>
            <button type="submit">Reveal (view)</button>
            <StatusLine result={revealError ? { ok: false, message: revealError } : null} />
            {revealed && (
              <div className="lookup-result">
                {revealed.name} · {revealed.id} · {revealed.course} · {shortAddress(revealed.address)}
              </div>
            )}
          </form>

          <form className="tx-form" onSubmit={loadScripts}>
            <h4>Scripts of an exam (public)</h4>
            <label className="field">
              <span>Exam ID</span>
              <input type="number" value={listExamId} onChange={(e) => setListExamId(e.target.value)} />
            </label>
            <button type="submit">Load scripts (view)</button>
            <StatusLine result={scriptsError ? { ok: false, message: scriptsError } : null} />
            {scripts && (
              <ul className="addr-list">
                {scripts.length === 0 && <li>No scripts registered</li>}
                {scripts.map((s) => (
                  <li key={s.sid}>
                    {s.sid} <span className="section-chip">Section {s.section === 1 ? 'A' : 'B'}</span>
                  </li>
                ))}
              </ul>
            )}
          </form>
        </div>
      </div>
    </div>
  )
}
